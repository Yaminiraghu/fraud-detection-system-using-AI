// server.js
const express = require('express');
const bodyParser = require('body-parser');
const { execSync } = require('child_process');
const fs = require('fs');

const app = express();
app.use(bodyParser.json());

app.post('/predict', (req, res) => {
    const features = req.body.features;  // Array of features
    try {
        fs.writeFileSync('features.json', JSON.stringify(features));

        // Run Python script for prediction
        const result = execSync('python3 predict.py').toString();
        res.json({ result: result.trim() });
    } catch (error) {
        res.status(500).send('Error processing request');
    }
});

app.listen(3000, () => {
    console.log('Server running on port 3000');
});