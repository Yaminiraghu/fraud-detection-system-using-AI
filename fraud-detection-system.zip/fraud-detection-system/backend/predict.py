import json
import joblib
import pandas as pd
from sklearn.preprocessing import StandardScaler

# Load trained model
model = joblib.load('fraud_detection_model.pkl')

# Load input features from the JSON file
with open('features.json', 'r') as f:
    features = json.load(f)

# Convert the features to a DataFrame
df = pd.DataFrame([features])

# Scale the input features (optional, depending on model requirements)
scaler = StandardScaler()
df = scaler.fit_transform(df)

# Make a prediction
prediction = model.predict(df)
print('Fraud' if prediction[0] == 1 else 'Not Fraud')
