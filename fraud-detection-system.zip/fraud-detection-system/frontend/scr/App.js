import React, { useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
    const [features, setFeatures] = useState([]);
    const [result, setResult] = useState('');

    const handleSubmit = async () => {
        try {
            const response = await axios.post('http://localhost:3000/predict', { features });
            setResult(response.data.result);
        } catch (error) {
            console.error('Error:', error);
        }
    };

    return (
        <div className="container">
            <h1>Fraud Detection</h1>
            <input
                type="text"
                placeholder="Enter features (comma-separated)"
                onChange={(e) => setFeatures(e.target.value.split(','))}
            />
            <button onClick={handleSubmit}>Check Fraud</button>
            <p>Result: {result}</p>
        </div>
    );
}

export default App;